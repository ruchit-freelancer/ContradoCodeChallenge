-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE InsertUpdateProduct 
	@ProductId bigint = 0
      ,@ProdCatId int
      ,@ProdName varchar(250)
      ,@ProdDescription varchar(max)
AS
BEGIN

IF @ProductId = 0

	INSERT INTO [dbo].[Product]
           ([ProdCatId]
           ,[ProdName]
           ,[ProdDescription])
     VALUES
           (@ProdCatId
           ,@ProdName
           ,@ProdDescription)
ELSE

    UPDATE Product SET [ProdCatId] = @ProdCatId,ProdName = @ProdName,ProdDescription = @ProdDescription
	WHERE ProductId = @ProductId
END
GO
