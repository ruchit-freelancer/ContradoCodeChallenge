﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TestCC.Models;
using TestCC.BL;
using System.Configuration;
using TestCC.BL.BO;

namespace TestCC.Controllers
{
    public class ProductController : ApiController
    {
        // GET api/<controller>
        public List<ProductModel> GetProductList()
        {
            List<ProductModel> ReturnList = new List<ProductModel>();
            string connString = Convert.ToString(ConfigurationManager.AppSettings["connString"]);
            BusinessLayer objBL = new BusinessLayer(connString);
            List<ProductBO> productList = objBL.GetProductList("GetProductList");
            //We can use AutoMapper classes instead
            foreach (ProductBO product in productList)
            {
                ProductModel obj = new ProductModel() { ProductID = product.ProductID, ProductName = product.ProductName, ProductDesc = product.ProductDesc,ProductCategoryName = product.ProductCategoryName };
                ReturnList.Add(obj);
            }
            return ReturnList;
        }

        public List<ProductCategoryModel> GetCategoryList()
        {
            List<ProductCategoryModel> ReturnList = new List<ProductCategoryModel>();
            string connString = Convert.ToString(ConfigurationManager.AppSettings["connString"]);
            BusinessLayer objBL = new BusinessLayer(connString);
            List<ProductCategoryBO> productCatList = objBL.GetProdCategoryList("GetProductCategoryList");
            foreach (ProductCategoryBO product in productCatList)
            {
                ProductCategoryModel obj = new ProductCategoryModel() { CategoryID = product.CategoryID, CategoryName = product.CategoryName };
                ReturnList.Add(obj);
            }
            return ReturnList;
        }

        [HttpPost]
        public int CreateUpdateProduct(ProductModel model)
        {
            ProductBO objBO = new ProductBO();
            objBO.ProductID = model.ProductID;
            objBO.ProductName = model.ProductName;
            objBO.ProductCatID = model.ProductCatID;
            objBO.ProductDesc = model.ProductDesc;
            string connString = Convert.ToString(ConfigurationManager.AppSettings["connString"]);
            BusinessLayer objBL = new BusinessLayer(connString);            
            return objBL.CreateUpdateProject("InsertUpdateProduct", objBO);
        }

        public ProductModel GetProductByID(int prodID)
        {
            string connString = Convert.ToString(ConfigurationManager.AppSettings["connString"]);
            BusinessLayer objBL = new BusinessLayer(connString);
            ProductModel objModel = new ProductModel();
            ProductBO objBO;
            objBO = objBL.GetProductByID("GetProductByID", prodID);
            objModel.ProductID = objBO.ProductID;
            objModel.ProductName = objBO.ProductName;
            objModel.ProductCatID = objBO.ProductCatID;
            objModel.ProductDesc = objBO.ProductDesc;
            return objModel;
        }
    }
}