﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestCC.Models
{
    public class ProductModel
    {
        public int ProductID { get; set; }

        public string ProductName { get; set; }

        public string ProductDesc { get; set; }

        public int ProductCatID { get; set; }

        public string ProductCategoryName { get; set; }
    }
}