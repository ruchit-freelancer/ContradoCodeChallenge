﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestCC.Models
{
    public class ProductCategoryModel
    {
        public int CategoryID { get; set; }

        public string CategoryName { get; set; }
    }
}