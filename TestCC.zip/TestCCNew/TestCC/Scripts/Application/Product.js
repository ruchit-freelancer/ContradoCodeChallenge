﻿var table;
//Load Data in Table when documents is ready  
$(document).ready(function () {
    loadData();
});

//Load Data function  
function loadData() {
    $.ajax({
        url: "/api/Product/GetProductList",
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            if (table == undefined)
                table = $('#ProductList').DataTable({
                    bSort: false,
                    'responsive': true,
                    "scrollX": true,
                    'processing': true,
                    'language': {
                        'loadingRecords': '&nbsp;',
                        'processing': '<div class="spinner"></div>',
                    },
                    "select": {
                        "style": "os",
                        info: false
                    },
                    aoColumns: [
                    { data: "prodid", sWidth: "20%" },
                    { data: "prodname", sWidth: "20%" },
                    { data: "proddesc", sWidth: "30%" },
                    { data: "prodcatname", swidth: "20%" },
                    { data: "edit", sWidth: "10%" }]
                });

            table.clear().draw();
            $.each(result, function (key, item) {
                var editlink = "<a id='EditLink' style='cursor:pointer' onclick=showCreateProduct('update'," + item.ProductID + ");>Edit</a>";
                table.rows.add([{
                    "prodid": item.ProductID,
                    "prodname": item.ProductName,
                    "proddesc": item.ProductDesc,
                    "prodcatname": item.ProductCategoryName,
                    "edit": editlink
                }]).draw();
            });
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

function showCreateProduct(mode, prodID) {

    $('#ProductID').val('');
    $('#Name').val('');
    $('#Category').val('');
    $('#Desc').val('');

    if (mode != 'insert') {
        $.ajax({
            url: "/api/Product/GetProductByID?prodID=" + prodID,
            type: "GET",
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            success: function (result) {
                $('#ProductID').val(result.ProductID);
                $('#Name').val(result.ProductName);
                $('#Desc').val(result.ProductDesc);
                $('#myModal').modal('show');
                loadCategories(result.ProductCatID);                
            },
            error: function (errormessage) {
                alert(errormessage.responseText);
            }
        });
    }
    else {
        $('#myModal').modal('show');
        loadCategories('');
    }

}

function CreateUpdateProduct(mode) {
    var productObj = {
        ProductID: $('#ProductID').val() == '' ? 0 : $('#ProductID').val(),
        ProductName: $('#Name').val(),
        ProductCatID: $('#Category').val(),
        ProductDesc: $('#Desc').val(),
    };
    $.ajax({
        url: "/api/Product/CreateUpdateProduct",
        data: JSON.stringify(productObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            loadData();
            $('#myModal').modal('hide');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

function loadCategories(catId) {

    $.ajax({
        type: "GET",
        url: "/api/Product/GetCategoryList",
        data: "{}",
        success: function (data) {
            var s = '<option value="-1">Please Select a Category</option>';
            for (var i = 0; i < data.length; i++) {
                s += '<option value="' + data[i].CategoryID + '">' + data[i].CategoryName + '</option>';
            }
            $("#Category").html(s);
            if (catId != '')
                $("#Category").val(catId);
        }

    });

}