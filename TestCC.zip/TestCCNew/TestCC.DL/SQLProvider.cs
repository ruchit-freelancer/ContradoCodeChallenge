﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace TestCC.DL
{
    public class SQLProvider
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataAdapter adapter;
        DataSet Results;
        public SQLProvider(string connString)
        {
            conn = new SqlConnection(connString);
        }
        public int ExecuteNonQuery(string procName, SqlParameter[] parameters)
        {
            try
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd = new SqlCommand(procName, this.conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddRange(parameters);
                int result = cmd.ExecuteNonQuery();
                conn.Close();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DataTable ExecuteDataTable(string procName, SqlParameter[] parameters)
        {
            try
            {
                cmd = new SqlCommand(procName, this.conn);
                cmd.CommandType = CommandType.StoredProcedure;
                if(parameters!= null)
                    cmd.Parameters.AddRange(parameters);
                adapter = new SqlDataAdapter(cmd);
                Results = new DataSet();
                adapter.Fill(Results);
                return Results.Tables[0];
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
