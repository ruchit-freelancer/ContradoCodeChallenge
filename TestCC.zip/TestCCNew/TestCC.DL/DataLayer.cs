﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace TestCC.DL
{
    public class DataLayer
    {
        readonly string connString;
        SQLProvider provider;
        public DataLayer(string connString)
        {
            this.connString = connString;
        }

        public DataTable GetList(string procName)
        {
            try
            {
                provider = new SQLProvider(this.connString);
                return provider.ExecuteDataTable(procName,null);
            }
            catch (Exception)
            {
                throw;
            }          
        }

        public DataTable GetDetailById(string procName,int ID)
        {
            provider = new SQLProvider(this.connString);
            return provider.ExecuteDataTable(procName, new SqlParameter[] {
                new SqlParameter("@ProductId",ID)});
        }
        
        public int CreateUpdateProduct(string procName,int ProdId,string ProductName,string ProductDesc,int ProdCatId)
        {
            provider = new SQLProvider(this.connString);
            return provider.ExecuteNonQuery(procName, new SqlParameter[] {
                new SqlParameter("@ProductId",ProdId),
                new SqlParameter("@ProdCatId",ProdCatId),
                new SqlParameter("@ProdName",ProductName),
                new SqlParameter("@ProdDescription",ProductDesc)
            });
        }
      
        
    }
}
