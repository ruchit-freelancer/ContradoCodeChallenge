﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestCC.BL.BO
{
    public class ProductCategoryBO
    {
        public int CategoryID { get; set; }

        public string CategoryName { get; set; }
    }
}
