﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestCC.BL.BO
{
    public class ProductBO
    {
        public int ProductID { get; set; }

        public string ProductName { get; set; }

        public string ProductDesc { get; set; }

        public int ProductCatID { get; set; }

        public string ProductCategoryName { get; set; }
    }
}
