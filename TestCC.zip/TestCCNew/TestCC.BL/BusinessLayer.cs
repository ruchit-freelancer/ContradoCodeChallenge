﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCC.DL;
using TestCC.BL.BO;

namespace TestCC.BL
{
    public class BusinessLayer
    {
        readonly string connString;
        List<ProductBO> ReturnList;
        List<ProductCategoryBO> CatReturnList;
        DataLayer objDL;
        DataTable ResultsTable;
        public BusinessLayer(string connString)
        {
            this.connString = connString;
        }

        public List<ProductBO> GetProductList(string procName)
        {
            ReturnList = new List<ProductBO>();
            objDL = new DataLayer(this.connString);
            ResultsTable = new DataTable();
            ResultsTable = objDL.GetList(procName);
            foreach (DataRow row in ResultsTable.Rows)
            {
                ProductBO obj = new ProductBO() { ProductID = Convert.ToInt32(row["ProductId"]), ProductName = Convert.ToString(row["ProdName"]), ProductDesc = Convert.ToString(row["ProdDescription"]), ProductCategoryName = Convert.ToString(row["CategoryName"]) };
                ReturnList.Add(obj);
            }
            return ReturnList;
        }

        public List<ProductCategoryBO> GetProdCategoryList(string procName)
        {
            CatReturnList = new List<ProductCategoryBO>();
            objDL = new DataLayer(this.connString);
            ResultsTable = new DataTable();
            ResultsTable = objDL.GetList(procName);
            foreach (DataRow row in ResultsTable.Rows)
            {
                ProductCategoryBO obj = new ProductCategoryBO { CategoryID = Convert.ToInt32(row["ProdCatId"]), CategoryName = Convert.ToString(row["CategoryName"]) };
                CatReturnList.Add(obj);
            }
            return CatReturnList;
        }

        public int CreateUpdateProject(string procName, ProductBO objBO)
        {
            objDL = new DataLayer(this.connString);
            return objDL.CreateUpdateProduct(procName, objBO.ProductID, objBO.ProductName, objBO.ProductDesc, objBO.ProductCatID);
        }

        public ProductBO GetProductByID(string procName, int prodID)
        {
            objDL = new DataLayer(this.connString);
            ResultsTable = new DataTable();
            ResultsTable = objDL.GetDetailById(procName, prodID);
            ProductBO returnObj = new ProductBO();
            if (ResultsTable.Rows.Count > 0)
            {
                returnObj.ProductID = Convert.ToInt32(ResultsTable.Rows[0]["ProductId"]);
                returnObj.ProductName = Convert.ToString(ResultsTable.Rows[0]["ProdName"]);
                returnObj.ProductDesc = Convert.ToString(ResultsTable.Rows[0]["ProdDescription"]);
                returnObj.ProductCatID = Convert.ToInt32(ResultsTable.Rows[0]["ProdCatId"]);
                returnObj.ProductCategoryName = Convert.ToString(ResultsTable.Rows[0]["CategoryName"]);
            }
            return returnObj;
        }
    }
}
